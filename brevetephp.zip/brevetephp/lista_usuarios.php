<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/estilos.css" type="text/css" rel="stylesheet"/>

<title>Lista de Usuarios</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <th align="center" scope="col"><table width="800" border="0" cellspacing="0" cellpadding="0" frame="border">
        <tr>
          <th colspan="3" bgcolor="#999999" scope="col">Listado de Usuarios</th>
        </tr>
        <tr>
          <td width="373" align="left" valign="top" bgcolor="#E2E2E2"><table width="100%" border="0" cellspacing="0" cellpadding="8">
            <tr>
              <th align="left" scope="col"><fieldset class="parrafo_negro">
                <legend>Datos de usuario</legend>
                <table width="81%" border="0" cellspacing="5" cellpadding="0">
                  <tr>
                    <th width="29%" align="left" class="parrafo_negro" scope="col">Codigo</th>
                    <th width="43%" align="left" class="parrafo_negro" scope="col"><label for="textfield4"></label>
                      <input type="text" name="textfield4" id="textfield4" /></th>
                    <td align="left" class="parrafo_negro" scope="col">&nbsp;</td>
                  </tr>
                  <tr>
                    <td align="left" class="parrafo_negro">Descripcion</td>
                    <td colspan="2" align="left"><label for="textfield2"></label>
                      <input name="textfield2" type="text" id="textfield2" size="35" /></td>
                  </tr>
                  <tr>
                    <td align="left" class="parrafo_negro">Contraseña</td>
                    <td align="left"><label for="textfield"></label>
                      <input type="text" name="textfield" id="textfield" /></td>
                    <td align="left" class="parrafo_negro"><input type="checkbox" name="checkbox" id="checkbox" />
                      Activo</td>
                  </tr>
                  <tr>
                    <td align="left" class="parrafo_negro">Nombre</td>
                    <td colspan="2" align="left"><label for="textfield3"></label>
                      <input name="textfield3" type="text" id="textfield3" size="35" /></td>
                  </tr>
                </table>
                <br />
              </fieldset></th>
            </tr>
          </table></td>
          <td width="268" align="left" valign="top" bgcolor="#E2E2E2"><table width="100%" border="0" cellspacing="0" cellpadding="8">
            <tr>
              <th align="left" scope="col"><fieldset>
                <legend class="parrafo_negro">Nivel</legend>
                <table width="100%" border="0" cellspacing="5" cellpadding="0">
                  <tr>
                    <th align="left" class="parrafo_negro" scope="col">
                    <input type="checkbox" name="checkbox2" id="checkbox2" />
                    <label for="checkbox2">Administrador General</label>
                      </th>
                  </tr>
                  <tr>
                    <td class="parrafo_negro"><input type="checkbox" name="checkbox3" id="checkbox3" />
                      <label for="checkbox3">Personal Administrativo</label></td>
                  </tr>
                </table>
              </fieldset></th>
            </tr>
          </table></td>
          <td width="109" valign="top" bgcolor="#E2E2E2"><table width="100%" border="0" cellspacing="0" cellpadding="8">
            <tr>
              <th scope="col"><table width="100%" border="0" cellspacing="5" cellpadding="0">
                <tr>
                  <th scope="col"><input name="button" type="submit" class="btn_numeros" id="button" value="Nuevo" /></th>
                </tr>
                <tr>
                  <td><input name="button2" type="submit" class="btn_numeros" id="button2" value="Modificar" /></td>
                </tr>
                <tr>
                  <td><input name="button3" type="submit" class="btn_numeros" id="button3" value="Grabar" /></td>
                </tr>
                <tr>
                  <td><input name="button4" type="submit" class="btn_numeros" id="button4" value="Cancelar" /></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
              </table></th>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td colspan="3" bgcolor="#E2E2E2">&nbsp;</td>
        </tr>
        <tr>
          <td colspan="3" bgcolor="#E2E2E2"><table width="100%" border="0" cellspacing="0" cellpadding="8">
            <tr>
              <th scope="col"><table width="100%" border="1" cellspacing="0" cellpadding="0" bordercolor="#DFDFDF">
                <tr>
                  <th bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                  <th bgcolor="#FFFFFF" class="parrafo_negro" scope="col">Codigo</th>
                  <th bgcolor="#FFFFFF" class="parrafo_negro" scope="col">Descripcion</th>
                  <th bgcolor="#FFFFFF" class="parrafo_negro" scope="col">Nombres</th>
                </tr>
                <tr>
                  <td bgcolor="#FFFFFF">&nbsp;</td>
                  <td bgcolor="#FFFFFF">&nbsp;</td>
                  <td bgcolor="#FFFFFF">&nbsp;</td>
                  <td bgcolor="#FFFFFF">&nbsp;</td>
                </tr>
                <tr>
                  <td bgcolor="#FFFFFF">&nbsp;</td>
                  <td bgcolor="#FFFFFF">&nbsp;</td>
                  <td bgcolor="#FFFFFF">&nbsp;</td>
                  <td bgcolor="#FFFFFF">&nbsp;</td>
                </tr>
                <tr>
                  <td bgcolor="#FFFFFF">&nbsp;</td>
                  <td bgcolor="#FFFFFF">&nbsp;</td>
                  <td bgcolor="#FFFFFF">&nbsp;</td>
                  <td bgcolor="#FFFFFF">&nbsp;</td>
                </tr>
                <tr>
                  <td height="60" colspan="4" bgcolor="#999999">&nbsp;</td>
                  </tr>
              </table></th>
            </tr>
          </table></td>
        </tr>
      </table></th>
    </tr>
  </table>
</form>
</body>
</html>
