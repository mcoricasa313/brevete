<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/estilos.css" type="text/css" rel="stylesheet"/>

<title>Menu Principal</title>
<style type="text/css">
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
</style>
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <th align="center" scope="col"><form id="form1" name="form1" method="post" action="">
      <table width="800" border="0" cellspacing="0" cellpadding="0" frame="box">
        <tr>
          <th colspan="4" align="left" bgcolor="#999999" style="color: #FFF" scope="col"> <span style="color: #999">X </span>Menu Principal</th>
          <th width="137" align="right" bgcolor="#999999" style="color: #FFF" scope="col"><input type="submit" name="button" id="button" value="X" style="color:#FFFFFF;background:#990000;font-weight:bold;border:0 px"/></th>
        </tr>
        <tr>
          <td colspan="5"><table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="5%" bgcolor="#E2E2E2"><input name="button6" type="submit" class="boton_1" id="button6" value="Inicio" onclick="location.href='menu_principal.php'"/></td>
              <td width="9%" bgcolor="#E2E2E2"><input name="button7" type="submit" class="boton_1" id="button7" value="Certificado" onclick="location.href='generar_certificado.php'" /></td>
              <td width="12%" bgcolor="#E2E2E2"><input name="button2" type="button" class="boton_1" id="button2" value="Proceso de Registro" onclick="location.href='registro_postulantes.php'"  /></td>
              <td width="16%" bgcolor="#E2E2E2"><input name="button3" type="submit" class="boton_1" id="button3" value="Mantenimiento de Registros"  /></td>
              <td width="7%" bgcolor="#E2E2E2"><input name="button4" type="submit" class="boton_1" id="button4" value="Consulta" /></td>
              <td width="8%" bgcolor="#E2E2E2"><input name="button5" type="submit" class="boton_1" id="button5" value="Reporte" /></td>
              <td width="29%" bgcolor="#E2E2E2">&nbsp;</td>
              <td width="7%" bgcolor="#E2E2E2">&nbsp;</td>
              <td width="7%" bgcolor="#E2E2E2">&nbsp;</td>
            </tr>
          </table></td>
          </tr>
        <tr>
          <td height="400" colspan="5" bgcolor="#E2E2E2">&nbsp;</td>
        </tr>
        <tr>
          <td width="130" align="center" style="font-size: 12px">JHONATAN</td>
          <td width="168" align="center" style="font-size: 12px">ONLINE</td>
          <td width="125" style="font-size: 12px">Jhonatan Bazalar</td>
          <td colspan="2" style="font-size: 12px">Fecha 14/11/2015</td>
          </tr>
      </table>
    </form></th>
  </tr>
</table>
</body>
</html>
