<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/estilos.css" type="text/css" rel="stylesheet"/>

<title>Reportes Logueo</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <th scope="col"><table width="800" border="0" cellspacing="0" cellpadding="0" frame="box">
        <tr>
          <th colspan="4" align="left" bgcolor="#999999" style="color: #FFF" scope="col"> <span style="color: #999">X </span>Menu Principal - [Reportes Logueo]</th>
          <th width="143" align="right" bgcolor="#999999" style="color: #FFF" scope="col"><input type="submit" name="button" id="button" value="X" style="color:#FFFFFF;background:#990000;font-weight:bold;border:0 px"/></th>
        </tr>
        <tr>
          <td width="130"><input name="button2" type="submit" class="btn_numeros" id="button2" value="Proceso de Registro" /></td>
          <td width="175"><input name="button3" type="submit" class="btn_numeros" id="button3" value="Mantenimiento de Registros" /></td>
          <td><input name="button4" type="submit" class="btn_numeros" id="button4" value="Consulta" /></td>
          <td width="234" align="left"><input type="submit" name="button5" id="button5" value="Reporte" /></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td height="100" colspan="5" align="left" valign="top" bgcolor="#E2E2E2"><table width="100%" border="0" cellspacing="0" cellpadding="8">
            <tr>
              <th scope="col"><fieldset>
                <legend>. </legend>
                <table width="100%" border="0" cellspacing="5" cellpadding="3">
                  <tr>
                    <th width="7%" align="left" scope="col"><span class="parrafo_negro">Desde</span></th>
                    <th width="19%" align="left" scope="col"><label for="textfield2"></label>
                      <input type="text" name="textfield" id="textfield2" /></th>
                    <th width="9%" rowspan="2" align="left" class="parrafo_negro" scope="col">Usuarios</th>
                    <th width="20%" rowspan="2" align="left" scope="col"><label for="select">
                      <select name="select2" id="select2" style="width:250px">
                      </select>
                    </label></th>
                    <th rowspan="2" align="left" scope="col"><label for="select2"></label>
                      <input type="checkbox" name="checkbox2" id="checkbox2" />
                      <label for="checkbox2" class="parrafo_negro">Todos</label></th>
                    <th width="11%" align="left" scope="col"><input name="button6" type="submit" class="btn_numeros" id="button6" value="Ver Reporte" /></th>
                  </tr>
                  <tr>
                    <td align="left"><span class="parrafo_negro">Hasta</span></td>
                    <td><label for="textfield3"></label>
                      <input type="text" name="textfield2" id="textfield3" /></td>
                    <td align="left"><input name="button7" type="submit" class="btn_numeros" id="button7" value="Cancelar" /></td>
                  </tr>
                </table>
                <br />
              </fieldset></th>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td height="200" colspan="5" valign="top" bgcolor="#E2E2E2"><table width="100%" border="0" cellspacing="0" cellpadding="8">
            <tr>
              <th scope="col"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <th height="250" align="left" valign="top" bgcolor="#999999" scope="col">&nbsp;</th>
                </tr>
              </table></th>
            </tr>
          </table></td>
        </tr>
        <tr class="parrafo_negro">
          <td align="center" style="font-size: 12px">JHONATAN</td>
          <td align="center" style="font-size: 12px">ONLINE</td>
          <td width="118" style="font-size: 12px">Jhonatan Bazalar</td>
          <td colspan="2" style="font-size: 12px">Fecha 14/11/2015</td>
        </tr>
      </table></th>
    </tr>
  </table>
</form>
</body>
</html>
