<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_brevete = "localhost";
$database_brevete = "bd_brevete";
$username_brevete = "root";
$password_brevete = "root";
$brevete = mysql_pconnect($hostname_brevete, $username_brevete, $password_brevete) or trigger_error(mysql_error(),E_USER_ERROR); 
?>