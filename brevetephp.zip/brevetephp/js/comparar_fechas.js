// JavaScript Document

function datos_impresion(){

	var fecha1 = new Date();
	var fecha2 = new Date();
	var fecha3 = new Date();
	var fecha4 = new Date();
	var fecha5 = new Date();
	var fecha6 = new Date();
	var fecha7 = new Date();
	var fecha8 = new Date();
	var fecha9 = new Date();
	var fecha10 = new Date();
	var fecha11 = new Date();
	var fecha12 = new Date();
	var fecha13 = new Date();

//

	var curso_fin1 = new Date();
	var curso_fin2 = new Date();
	var curso_fin3 = new Date();
	var curso_fin4 = new Date();
	var curso_fin5 = new Date();
	var curso_fin6 = new Date();
	var curso_fin7 = new Date();
	var curso_fin8 = new Date();
	var curso_fin9 = new Date();
	var curso_fin10 = new Date();
	var curso_fin11 = new Date();
	var curso_fin12 = new Date();
	var curso_fin13 = new Date();


	var auxiliar = new Date();
	var fechas = [];
	var fechas_finales = [];
	var notas = [];


	fecha1 = document.getElementById("curso_inicio").value;
	fecha2 = document.getElementById("curso_inicio2").value;
	fecha3 = document.getElementById("curso_inicio3").value;
	fecha4 = document.getElementById("curso_inicio4").value;
	fecha5 = document.getElementById("curso_inicio5").value;
	fecha6 = document.getElementById("curso_inicio6").value;
	fecha7 = document.getElementById("curso_inicio7").value;
	fecha8 = document.getElementById("curso_inicio8").value;
	fecha9 = document.getElementById("curso_inicio9").value;
	fecha10 = document.getElementById("curso_inicio10").value;
	fecha11 = document.getElementById("curso_inicio11").value;
	fecha12 = document.getElementById("curso_inicio12").value;
	fecha13 = document.getElementById("curso_inicio13").value;


	curso_fin1 = document.getElementById("curso_fin").value;
	curso_fin2 = document.getElementById("curso_fin2").value;
	curso_fin3 = document.getElementById("curso_fin3").value;
	curso_fin4 = document.getElementById("curso_fin4").value;
	curso_fin5 = document.getElementById("curso_fin5").value;
	curso_fin6 = document.getElementById("curso_fin6").value;
	curso_fin7 = document.getElementById("curso_fin7").value;
	curso_fin8 = document.getElementById("curso_fin8").value;
	curso_fin9 = document.getElementById("curso_fin9").value;
	curso_fin10 = document.getElementById("curso_fin10").value;
	curso_fin11 = document.getElementById("curso_fin11").value;
	curso_fin12 = document.getElementById("curso_fin12").value;
	curso_fin13 = document.getElementById("curso_fin13").value;

	

	var nota1 = document.getElementById("nota").value;
	var nota2 = document.getElementById("nota2").value;
	var nota3 = document.getElementById("nota3").value;
	var nota4 = document.getElementById("nota4").value;
	var nota5 = document.getElementById("nota5").value;
	var nota6 = document.getElementById("nota6").value;
	var nota7 = document.getElementById("nota7").value;
	var nota8 = document.getElementById("nota8").value;
	var nota9 = document.getElementById("nota9").value;
	var nota10 = document.getElementById("nota10").value;
	var nota11 = document.getElementById("nota11").value;
	var nota12 = document.getElementById("nota12").value;
	var nota13 = document.getElementById("nota13").value;

	

	
	fechas = [fecha1,fecha2,fecha3,fecha4,fecha5,fecha6,fecha7,fecha8,fecha9,fecha10,fecha11,fecha12,fecha13];
	fechas_finales = [curso_fin1,curso_fin2,curso_fin3,curso_fin4,curso_fin5,curso_fin6,curso_fin7,curso_fin8,curso_fin9,curso_fin10,curso_fin11,curso_fin12,curso_fin13];
	
		
	notas = [nota1,nota2,nota3,nota4,nota5,nota6,nota7,nota8,nota9,nota10,nota11,nota12,nota13];

//	var promedio = (nota1+nota2+nota3+nota4+nota5+nota6)/6;

	var suma = 0;
	notas.filter(String);
	for(var i=0;i<notas.length;i++){
		suma = suma + Number(notas[i]);
	}

	var promedio = suma/notas.filter(String).length;
	var minimo = new Date();
	
	fechas.sort();
	fechas = fechas.filter(String);
	minimo = fechas[0];


	fechas_finales.sort();
	fechas_finales = fechas_finales.filter(String);
	minimo_finales = fechas_finales[fechas_finales.length-1];
	

	document.getElementById("fecha_inicio_impresion").value=minimo;
	document.getElementById("fecha_final_impresion").value=minimo_finales;
	document.getElementById("promedio").value=promedio;
	document.getElementById("certificado_impresion").value=document.getElementById("id_capacitacion").value;

	}
	

	function agregar_fila(){
		//boton 7
		document.getElementById("fila09").style.display= "table-row";
		document.getElementById("button7").style.display= "none";
		document.getElementById("button8").style.display= "block";

		
	}
	function agregar_fila2(){
		//boton 8
		document.getElementById("fila10").style.display= "table-row";
		document.getElementById("button8").style.display= "none";
		document.getElementById("button9").style.display= "block";
	}
	function agregar_fila3(){
		//boton 9
		document.getElementById("fila11").style.display= "table-row";
		document.getElementById("button9").style.display= "none";
		document.getElementById("button10").style.display= "block";
	}
	function agregar_fila4(){
		//boton 10
		document.getElementById("fila12").style.display= "table-row";
		document.getElementById("button10").style.display= "none";
		document.getElementById("button11").style.display= "block";
	}
	function agregar_fila5(){
		// boton 11
		document.getElementById("fila13").style.display= "table-row";
		document.getElementById("button11").style.display= "none";
		document.getElementById("button12").style.display= "block";
	}
	function agregar_fila6(){
		// boton 12
		document.getElementById("fila14").style.display= "table-row";
		document.getElementById("button12").style.display= "none";
		document.getElementById("button13").style.display= "block";
	}
	function agregar_fila7(){
		// boton 13
		document.getElementById("fila15").style.display= "table-row";
		document.getElementById("button13").style.display= "none";
		document.getElementById("button14").style.display= "block";
	}
	
	
	function borrar_fila15(){
		document.getElementById("fila15").style.display= "none";
		document.getElementById("button7").style.display= "none";
		document.getElementById("button8").style.display= "none";
		document.getElementById("button9").style.display= "none";
		document.getElementById("button10").style.display= "none";
		document.getElementById("button11").style.display= "none";
		document.getElementById("button12").style.display= "none";
		document.getElementById("button13").style.display= "block";
		document.getElementById("button14").style.display= "none";
		

	}
	function borrar_fila14(){
		document.getElementById("fila14").style.display= "none";
		document.getElementById("button7").style.display= "none";
		document.getElementById("button8").style.display= "none";
		document.getElementById("button9").style.display= "none";
		document.getElementById("button10").style.display= "none";
		document.getElementById("button11").style.display= "none";
		document.getElementById("button12").style.display= "block";
		document.getElementById("button13").style.display= "none";
		document.getElementById("button14").style.display= "none";

	}
	function borrar_fila13(){
document.getElementById("fila13").style.display= "none";
		document.getElementById("button7").style.display= "none";
		document.getElementById("button8").style.display= "none";
		document.getElementById("button9").style.display= "none";
		document.getElementById("button10").style.display= "none";
		document.getElementById("button11").style.display= "block";
		document.getElementById("button12").style.display= "none";
		document.getElementById("button13").style.display= "none";
		document.getElementById("button14").style.display= "none";	}
		
	function borrar_fila12(){
document.getElementById("fila12").style.display= "none";
		document.getElementById("button7").style.display= "none";
		document.getElementById("button8").style.display= "none";
		document.getElementById("button9").style.display= "none";
		document.getElementById("button10").style.display= "block";
		document.getElementById("button11").style.display= "none";
		document.getElementById("button12").style.display= "none";
		document.getElementById("button13").style.display= "none";
		document.getElementById("button14").style.display= "none";	}
		
	function borrar_fila11(){
document.getElementById("fila11").style.display= "none";
		document.getElementById("button7").style.display= "none";
		document.getElementById("button8").style.display= "none";
		document.getElementById("button9").style.display= "block";
		document.getElementById("button10").style.display= "none";
		document.getElementById("button11").style.display= "none";
		document.getElementById("button12").style.display= "none";
		document.getElementById("button13").style.display= "none";
		document.getElementById("button14").style.display= "none";	}
	function borrar_fila10(){
document.getElementById("fila10").style.display= "none";
		document.getElementById("button7").style.display= "none";
		document.getElementById("button8").style.display= "block";
		document.getElementById("button9").style.display= "none";
		document.getElementById("button10").style.display= "none";
		document.getElementById("button11").style.display= "none";
		document.getElementById("button12").style.display= "none";
		document.getElementById("button13").style.display= "none";
		document.getElementById("button14").style.display= "none";	}
		
	function borrar_fila09(){
document.getElementById("fila09").style.display= "none";
		document.getElementById("button7").style.display= "block";
		document.getElementById("button8").style.display= "none";
		document.getElementById("button9").style.display= "none";
		document.getElementById("button10").style.display= "none";
		document.getElementById("button11").style.display= "none";
		document.getElementById("button12").style.display= "none";
		document.getElementById("button13").style.display= "none";
		document.getElementById("button14").style.display= "none";	}