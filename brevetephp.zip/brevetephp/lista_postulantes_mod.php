<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/estilos.css" type="text/css" rel="stylesheet"/>

<title>Lista postulantes - Modificar</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <th scope="col"><table width="800" border="0" cellspacing="0" cellpadding="0" frame="border">
        <tr>
          <th align="left" bgcolor="#999999" scope="col"> <span style="color: #999">X </span><span style="color: #FFF">Registro de Postulantes</span></th>
        </tr>
        <tr>
          <td><table width="100%" border="0" cellspacing="0" cellpadding="5">
            <tr>
              <th align="left" bgcolor="#E2E2E2" scope="col"><img src="img/logo.jpg" alt="" width="220" height="58" /></th>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td><table width="100%" border="0" cellspacing="0" cellpadding="5">
            <tr>
              <th width="186" align="left" bgcolor="#E2E2E2" style="color: #000" scope="col">Codigo</th>
              <th width="167" align="left" bgcolor="#E2E2E2" scope="col"><label for="textfield"></label>
                <input name="textfield" type="text" id="textfield" size="10" /></th>
              <th width="121" align="left" bgcolor="#E2E2E2" scope="col">&nbsp;</th>
              <th width="144" align="left" bgcolor="#E2E2E2" scope="col">&nbsp;</th>
              <th width="132" align="left" bgcolor="#E2E2E2" scope="col">&nbsp;</th>
            </tr>
            <tr>
              <td align="left" bgcolor="#E2E2E2" style="color: #000">Nombres</td>
              <td colspan="4" align="left" bgcolor="#E2E2E2"><label for="textfield2"></label>
                <input name="textfield2" type="text" id="textfield2" size="100" /></td>
            </tr>
            <tr>
              <td align="left" bgcolor="#E2E2E2" style="color: #000">Tramite</td>
              <td align="left" bgcolor="#E2E2E2"><label for="select"></label>
                <select name="select" id="select">
                </select></td>
              <td width="121" align="left" bgcolor="#E2E2E2" style="color: #000">N° Licencia</td>
              <td align="left" bgcolor="#E2E2E2"><label for="textfield3"></label>
                <input type="text" name="textfield3" id="textfield3" /></td>
              <td align="left" bgcolor="#E2E2E2">&nbsp;</td>
            </tr>
            <tr>
              <td align="left" bgcolor="#E2E2E2" style="color: #000">Fecha Nacimiento</td>
              <td align="left" bgcolor="#E2E2E2"><label for="select2"></label>
                <select name="select2" id="select2">
                </select></td>
              <td align="left" bgcolor="#E2E2E2" style="color: #000">Revalidacion</td>
              <td align="left" bgcolor="#E2E2E2"><label for="textfield4"></label>
                <input type="text" name="textfield4" id="textfield4" /></td>
              <td align="left" bgcolor="#E2E2E2">&nbsp;</td>
            </tr>
            <tr>
              <td align="left" bgcolor="#E2E2E2" style="color: #000">Fecha Medico</td>
              <td align="left" bgcolor="#E2E2E2"><label for="select3"></label>
                <select name="select3" id="select3">
                </select></td>
              <td align="left" bgcolor="#E2E2E2" style="color: #000">E-Mail</td>
              <td align="left" bgcolor="#E2E2E2"><label for="textfield5"></label>
                <input type="text" name="textfield5" id="textfield5" /></td>
              <td align="left" bgcolor="#E2E2E2">&nbsp;</td>
            </tr>
            <tr>
              <td align="left" bgcolor="#E2E2E2" style="color: #000">Tipo de Doc</td>
              <td align="left" bgcolor="#E2E2E2"><label for="select4"></label>
                <select name="select4" id="select4">
                </select></td>
              <td colspan="2" rowspan="2" align="left" bgcolor="#E2E2E2"><table width="120" border="0" cellspacing="3" cellpadding="0">
                <tr>
                  <th scope="col"><input type="submit" name="button" id="button" value="Grabar" /></th>
                  <th scope="col"><input type="submit" name="button2" id="button2" value="Cancelar" /></th>
                </tr>
              </table></td>
              <td align="left" bgcolor="#E2E2E2">&nbsp;</td>
            </tr>
            <tr>
              <td align="left" bgcolor="#E2E2E2" style="color: #000">N° de Documento</td>
              <td align="left" bgcolor="#E2E2E2"><label for="textfield6"></label>
                <input type="text" name="textfield6" id="textfield6" /></td>
              <td align="left" bgcolor="#E2E2E2">&nbsp;</td>
            </tr>
            <tr>
              <td width="186" align="left" bgcolor="#E2E2E2" style="color: #000">Dirección</td>
              <td colspan="4" align="left" bgcolor="#E2E2E2"><label for="textfield7"></label>
                <input name="textfield7" type="text" id="textfield7" size="100" /></td>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td bgcolor="#E2E2E2">&nbsp;</td>
        </tr>
      </table></th>
    </tr>
  </table>
</form>
</body>
</html>
