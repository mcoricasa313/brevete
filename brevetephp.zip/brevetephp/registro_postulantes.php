<?php require_once('Connections/brevete.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO postulantes (nom_postulante, fecha_nac, fecha_medico, id_tramite, num_licencia, id_tipodoc, num_documento, ds_revalidacion, ds_direccion, email) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['txt_nombres'], "text"),
                       GetSQLValueString($_POST['datepicker'], "date"),
                       GetSQLValueString($_POST['datepicker2'], "date"),
                       GetSQLValueString($_POST['cb_tramite'], "text"),
                       GetSQLValueString($_POST['txt_licencia'], "text"),
                       GetSQLValueString($_POST['cb_tipodoc'], "text"),
                       GetSQLValueString($_POST['txt_dni'], "text"),
                       GetSQLValueString($_POST['txt_revalidacion'], "text"),
                       GetSQLValueString($_POST['txt_direccion'], "text"),
                       GetSQLValueString($_POST['txt_mail'], "text"));

  mysql_select_db($database_brevete, $brevete);
  $Result1 = mysql_query($insertSQL, $brevete) or die(mysql_error());
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:spry="http://ns.adobe.com/spry">
<head>
<link href="css/estilos.css" type="text/css" rel="stylesheet"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

 <link rel="stylesheet" href="jquery/jquery-ui.css">
  <script src="jquery/jquery-1.10.2.js"></script>
  <script src="jquery/jquery-ui.js"></script>
<script src="SpryAssets/SpryData.js" type="text/javascript"></script>
  <script src="SpryAssets/SpryHTMLDataSet.js" type="text/javascript"></script>
  <script>
  $(function() {
    $( "#datepicker" ).datepicker({
      showOn: "button",
      buttonImage: "img/calendar.gif",
      buttonImageOnly: true,
      buttonText: "Select date"
    });
	 $('#datepicker').datepicker('option', {dateFormat: 'yy-mm-dd'});
  });
  </script>

<script>
$(function() {
    $( "#datepicker2" ).datepicker({
      showOn: "button",
      buttonImage: "img/calendar.gif",
      buttonImageOnly: true,
      buttonText: "Select date"
    });
		 $('#datepicker2').datepicker('option', {dateFormat: 'yy-mm-dd'});
  });
var tramite = new Spry.Data.HTMLDataSet("persistencia/tramite.html", "tramite", {useCache: false});
var tipo_documento = new Spry.Data.HTMLDataSet("persistencia/tipo_documento.html", "tipo_documento", {sortOnLoad: "Id", sortOrderOnLoad: "ascending"});
</script>


<title>Registrar Postulantes</title>
</head>

<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <th align="center" scope="col"><form id="form1" name="form1" method="POST" action="<?php echo $editFormAction; ?>">
      <table width="800" border="0" cellspacing="0" cellpadding="0" frame="border">
        <tr>
          <th align="left" bgcolor="#999999" scope="col"> <span style="color: #999">X </span><span style="color: #FFF">Registro de Postulantes</span></th>
        </tr>
        <tr>
          <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <th align="left" bgcolor="#E2E2E2" scope="col"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td width="5%" bgcolor="#E2E2E2"><input name="button6" type="submit" class="boton_1" id="button6" value="Inicio" /></td>
                  <td width="9%" bgcolor="#E2E2E2"><input name="button7" type="submit" class="boton_1" id="button7" value="Certificado" /></td>
                  <td width="12%" bgcolor="#E2E2E2"><input name="button3" type="button" class="boton_1" id="button3" value="Proceso de Registro" onclick="location.href='registro_postulantes.php'"  /></td>
                  <td width="16%" bgcolor="#E2E2E2"><input name="button3" type="submit" class="boton_1" id="button4" value="Mantenimiento de Registros" /></td>
                  <td width="7%" bgcolor="#E2E2E2"><input name="button4" type="submit" class="boton_1" id="button5" value="Consulta" /></td>
                  <td width="8%" bgcolor="#E2E2E2"><input name="button5" type="submit" class="boton_1" id="button6" value="Reporte" /></td>
                  <td width="29%" bgcolor="#E2E2E2">&nbsp;</td>
                  <td width="7%" bgcolor="#E2E2E2">&nbsp;</td>
                  <td width="7%" bgcolor="#E2E2E2">&nbsp;</td>
                </tr>
              </table></th>
            </tr>
            <tr>
              <th align="left" bgcolor="#E2E2E2" scope="col"><img src="img/logo.jpg" width="220" height="58" /></th>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td><table width="100%" border="0" cellspacing="0" cellpadding="8">
            <tr>
              <th bgcolor="#E2E2E2" scope="col"><table width="100%" border="0" cellspacing="0" cellpadding="1">
                <tr>
                  <th width="230" align="left" bgcolor="#E2E2E2" class="parrafo_negro_pequeno" style="color: #000" scope="col">Codigo</th>
                  <th align="left" bgcolor="#E2E2E2" scope="col"><label for="textfield"></label>
                    <input name="txt_codigo" type="text" id="textfield" size="10" /></th>
                  <th align="left" bgcolor="#E2E2E2" scope="col">&nbsp;</th>
                  <th align="left" bgcolor="#E2E2E2" scope="col">&nbsp;</th>
                  <th align="left" bgcolor="#E2E2E2" scope="col">&nbsp;</th>
                </tr>
                <tr>
                  <td align="left" bgcolor="#E2E2E2" class="parrafo_negro_pequeno" style="color: #000">Nombres</td>
                  <td colspan="4" align="left" bgcolor="#E2E2E2"><label for="txt_nombres"></label>
                    <input name="txt_nombres" type="text" id="txt_nombres" size="90" /></td>
                </tr>
                <tr>
                  <td align="left" bgcolor="#E2E2E2" class="parrafo_negro_pequeno" style="color: #000">Tramite</td>
                  <td align="left" bgcolor="#E2E2E2"><div spry:region="tramite">
                    <select name="select2" spry:repeatchildren="tramite">
                      <option value="{Nombre}">{Nombre}</option>
                    </select>
                  </div>                    <label for="cb_tipodoc"></label></td>
                  <td width="99" align="left" bgcolor="#E2E2E2" class="parrafo_negro_pequeno" style="color: #000">N° Licencia</td>
                  <td align="left" bgcolor="#E2E2E2"><label for="txt_licencia"></label>
                    <input type="text" name="txt_licencia" id="txt_licencia" /></td>
                  <td align="left" bgcolor="#E2E2E2">&nbsp;</td>
                </tr>
                <tr>
                  <td align="left" bgcolor="#E2E2E2" class="parrafo_negro_pequeno" style="color: #000">Fecha Nacimiento</td>
                  <td align="left" bgcolor="#E2E2E2"><label for="cb_tramite"></label>
                    <label for="datepicker"></label>
                    <input type="text" name="datepicker" id="datepicker" value=""/></td>
                  <td align="left" bgcolor="#E2E2E2" class="parrafo_negro_pequeno" style="color: #000">Revalidacion</td>
                  <td align="left" bgcolor="#E2E2E2"><label for="txt_revalidacion"></label>
                    <input type="text" name="txt_revalidacion" id="txt_revalidacion" /></td>
                  <td align="left" bgcolor="#E2E2E2">&nbsp;</td>
                </tr>
                <tr>
                  <td align="left" bgcolor="#E2E2E2" class="parrafo_negro_pequeno" style="color: #000">Fecha Medico</td>
                  <td align="left" bgcolor="#E2E2E2"><label for="select3"></label>
                    <label for="datepicker2"></label>
                    <input type="text" name="datepicker2" id="datepicker2" value=""/></td>
                  <td align="left" bgcolor="#E2E2E2" class="parrafo_negro_pequeno" style="color: #000">E-Mail</td>
                  <td align="left" bgcolor="#E2E2E2"><label for="txt_mail"></label>
                    <input type="text" name="txt_mail" id="txt_mail" /></td>
                  <td align="left" bgcolor="#E2E2E2">&nbsp;</td>
                </tr>
                <tr>
                  <td align="left" bgcolor="#E2E2E2" class="parrafo_negro_pequeno" style="color: #000">Tipo de Doc</td>
                  <td align="left" bgcolor="#E2E2E2"><div spry:region="tipo_documento">
                    <select name="select" spry:repeatchildren="tipo_documento">
                      <option value="{Nombre}">{Nombre}</option>
                    </select>
                  </div>                    <label for="select4"></label></td>
                  <td colspan="2" rowspan="2" align="left" bgcolor="#E2E2E2"><table width="120" border="0" cellspacing="3" cellpadding="0">
                    <tr>
                      <th scope="col"><input type="submit" name="button" id="button" value="Grabar" /></th>
                      <th scope="col"><input type="submit" name="button2" id="button2" value="Cancelar" /></th>
                    </tr>
                  </table></td>
                  <td align="left" bgcolor="#E2E2E2">&nbsp;</td>
                </tr>
                <tr>
                  <td align="left" bgcolor="#E2E2E2" class="parrafo_negro_pequeno" style="color: #000">N° de Documento</td>
                  <td align="left" bgcolor="#E2E2E2"><label for="txt_dni"></label>
                    <input type="text" name="txt_dni" id="txt_dni" /></td>
                  <td align="left" bgcolor="#E2E2E2">&nbsp;</td>
                </tr>
                <tr>
                  <td align="left" bgcolor="#E2E2E2" class="parrafo_negro_pequeno" style="color: #000">Dirección</td>
                  <td colspan="4" align="left" bgcolor="#E2E2E2"><label for="txt_direccion"></label>
                    <input name="txt_direccion" type="text" id="txt_direccion" size="90" /></td>
                </tr>
              </table></th>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td bgcolor="#E2E2E2">&nbsp;</td>
        </tr>
      </table>
      <input type="hidden" name="MM_insert" value="form1" />
    </form></th>
  </tr>
</table>
</body>
</html>
