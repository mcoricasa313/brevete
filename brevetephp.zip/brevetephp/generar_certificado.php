<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/estilos.css" type="text/css" rel="stylesheet"/>

<title>Generar Certificado</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table width="100%" border="0" cellspacing="0" cellpadding="3">
    <tr>
      <th scope="col"><table width="600" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <th bgcolor="#999999" scope="col">Generar Certificado</th>
        </tr>
        <tr>
          <td bgcolor="#E2E2E2"><table width="100%" border="0" cellspacing="5" cellpadding="0">
            <tr>
              <th width="28%" align="left" bgcolor="#E2E2E2" style="color: #000" scope="col">N° Documento</th>
              <th width="27%" align="left" bgcolor="#E2E2E2" scope="col"><label for="textfield"></label>
                <input type="text" name="textfield" id="textfield" /></th>
              <th width="10%" align="left" bgcolor="#E2E2E2" scope="col"><input type="submit" name="button" id="button" value="Buscar" /></th>
              <th width="22%" align="left" bgcolor="#E2E2E2" scope="col"><input type="submit" name="button2" id="button2" value="Generar Certificado" /></th>
              <th width="12%" align="left" bgcolor="#E2E2E2" scope="col"><input type="submit" name="button3" id="button3" value="Cancelar" /></th>
              <th width="1%" align="left" scope="col">&nbsp;</th>
            </tr>
            <tr>
              <td height="200" colspan="5" align="left" bgcolor="#8F8F8F">&nbsp;</td>
              <td align="left">&nbsp;</td>
            </tr>
          </table></td>
        </tr>
      </table></th>
    </tr>
  </table>
</form>
</body>
</html>
