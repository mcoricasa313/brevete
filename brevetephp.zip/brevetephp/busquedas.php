<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/estilos.css" type="text/css" rel="stylesheet"/>

<title>Busquedas</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <th scope="col"><table width="900" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <th bgcolor="#999999" scope="col">Busquedas</th>
        </tr>
        <tr>
          <td bgcolor="#E2E2E2"><table width="100%" border="0" cellspacing="8" cellpadding="0">
            <tr>
              <th align="left" scope="col"><fieldset>
                <legend class="parrafo_negro">Busqueda</legend>
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr class="parrafo_negro">
                    <th width="10%" align="left" class="parrafo_negro" scope="col">Buscar</th>
                    <th width="170" align="left" scope="col"><label for="select2"></label>
                      <select name="select" class="combobox" id="select2">
                      </select></th>
                    <th width="170" align="left" scope="col"><label for="select3"></label>
                      <select name="select2" class="combobox" id="select3">
                      </select>
                      <label for="textfield"></label></th>
                    <th width="27%" align="left" scope="col"><input type="text" name="textfield" id="textfield" /></th>
                    <th width="8%" align="left" scope="col"><input type="submit" name="button" id="button" value="Aceptar" /></th>
                    <th width="8%" align="left" scope="col"><input type="submit" name="button2" id="button2" value="Cancelar" /></th>
                    <th width="5%" align="left" scope="col">&nbsp;</th>
                  </tr>
                </table>
              </fieldset></th>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td bgcolor="#E2E2E2">&nbsp;</td>
        </tr>
        <tr>
          <td bgcolor="#E2E2E2"><table width="100%" border="0" cellspacing="0" cellpadding="8">
            <tr>
              <th scope="col"><table width="100%" border="1" cellspacing="0" cellpadding="0" bordercolor="#CACACA">
                <tr>
                  <th bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                  <th bgcolor="#FFFFFF" class="parrafo_negro_small" scope="col">Conductor</th>
                  <th bgcolor="#FFFFFF" class="parrafo_negro_small" scope="col">Fecha nac</th>
                  <th bgcolor="#FFFFFF" class="parrafo_negro_small" scope="col">Tramite</th>
                  <th bgcolor="#FFFFFF" class="parrafo_negro_small" scope="col">Nro Licencia</th>
                  <th bgcolor="#FFFFFF" class="parrafo_negro_small" scope="col">Tipo Doc</th>
                  <th bgcolor="#FFFFFF" class="parrafo_negro_small" scope="col">Num Doc</th>
                  <th bgcolor="#FFFFFF" class="parrafo_negro_small" scope="col">Revalidacion</th>
                </tr>
                <tr>
                  <th bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                  <th bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                  <th bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                  <th bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                  <th bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                  <th bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                  <th bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                  <th bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                </tr>
                <tr>
                  <th bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                  <th bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                  <th bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                  <th bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                  <th bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                  <th bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                  <th bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                  <th bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                </tr>
                <tr>
                  <th bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                  <th bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                  <th bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                  <th bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                  <th bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                  <th bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                  <th bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                  <th bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                </tr>
              </table></th>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td bgcolor="#E2E2E2"><table width="100%" border="0" cellspacing="0" cellpadding="8">
            <tr>
              <th width="48%" align="left" scope="col"><fieldset>
                <legend class="parrafo_negro">Datos Capacitacion</legend>
                <table width="100%" border="0" cellspacing="5" cellpadding="0">
                  <tr>
                    <th width="55%" align="left" class="parrafo_negro_small" scope="col">Capacitacion</th>
                    <th width="18%" align="left" scope="col"><label for="textfield2"></label>
                      <input name="textfield2" type="text" id="textfield2" size="10" /></th>
                    <th width="19%" class="parrafo_negro_small" scope="col">Promedio</th>
                    <th width="8%" scope="col"><label for="textfield3"></label>
                      <input name="textfield3" type="text" id="textfield3" size="4" /></th>
                  </tr>
                  <tr>
                    <td align="left" class="parrafo_negro_small">Num Certificado</td>
                    <td><label for="textfield4"></label>
                      <input name="textfield4" type="text" id="textfield4" size="10" /></td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
                  <tr>
                    <td align="left" class="parrafo_negro_small">Fecha inicio</td>
                    <td><label for="textfield5"></label>
                      <input name="textfield5" type="text" id="textfield5" size="10" /></td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
                  <tr>
                    <td height="22" align="left" class="parrafo_negro_small">Fecha Fin</td>
                    <td><label for="textfield6"></label>
                      <input name="textfield6" type="text" id="textfield6" size="10" /></td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
                </table>
                <br />
              </fieldset></th>
              <th width="46%" align="left" valign="top" scope="col"><table width="100%" border="0" cellspacing="0" cellpadding="8">
                <tr>
                  <th align="left" scope="col"><fieldset>
                    <legend class="parrafo_negro">Practica de Manejo</legend>
                    <table width="100%" border="0" cellspacing="5" cellpadding="0">
                      <tr>
                        <th width="60%" align="left" class="parrafo_negro_small" scope="col"><span class="parrafo_negro">Primera Practica</span></th>
                        <th width="15%" align="left" class="parrafo_negro_small" scope="col">Horas</th>
                        <th width="25%" align="left" scope="col"><label for="textfield7"></label>
                          <input name="textfield7" type="text" id="textfield7" size="10" /></th>
                      </tr>
                      <tr>
                        <td align="left" class="parrafo_negro_small">&nbsp;</td>
                        <td align="left" class="parrafo_negro_small">Fecha</td>
                        <td><label for="textfield8"></label>
                          <input name="textfield8" type="text" id="textfield8" size="10" /></td>
                      </tr>
                      <tr>
                        <td align="left" class="parrafo_negro_small">Segunda Practica</td>
                        <th align="left" class="parrafo_negro_small" scope="col">Horas</th>
                        <td><input name="textfield9" type="text" id="textfield9" size="10" /></td>
                      </tr>
                      <tr>
                        <td align="left">&nbsp;</td>
                        <td align="left" class="parrafo_negro_small">Fecha</td>
                        <td><input name="textfield10" type="text" id="textfield10" size="10" /></td>
                      </tr>
                      <tr>
                        <td align="left">&nbsp;</td>
                        <td>&nbsp;</td>
                        <td>&nbsp;</td>
                      </tr>
                  </table>
                  </fieldset></th>
                </tr>
              </table></th>
              <th width="6%" align="center" scope="col"><img src="img/logo.jpg" width="200" height="48" /></th>
            </tr>
          </table></td>
        </tr>
        <tr>
          <td bgcolor="#E2E2E2"><table width="100%" border="0" cellspacing="0" cellpadding="8">
            <tr>
              <th align="left" scope="col"><fieldset>
                <legend class="parrafo_negro">Resultados Cursos</legend>
                <table width="100%" border="1" cellspacing="0" cellpadding="0" bordercolor="#C6ECFF">
                  <tr>
                    <th width="5%" bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                    <th width="12%" bgcolor="#FFFFFF" class="parrafo_negro_small" scope="col">Curso</th>
                    <th width="11%" bgcolor="#FFFFFF" class="parrafo_negro_small" scope="col">Nota</th>
                    <th width="17%" bgcolor="#FFFFFF" class="parrafo_negro_small" scope="col">Fecha Curso</th>
                    <th width="17%" bgcolor="#FFFFFF" class="parrafo_negro_small" scope="col">Local</th>
                    <th width="38%" rowspan="5" bgcolor="#666666" scope="col">&nbsp;</th>
                  </tr>
                  <tr>
                    <td bgcolor="#FFFFFF">&nbsp;</td>
                    <td bgcolor="#FFFFFF">&nbsp;</td>
                    <td bgcolor="#FFFFFF">&nbsp;</td>
                    <td bgcolor="#FFFFFF">&nbsp;</td>
                    <td bgcolor="#FFFFFF">&nbsp;</td>
                    </tr>
                  <tr>
                    <td bgcolor="#FFFFFF">&nbsp;</td>
                    <td bgcolor="#FFFFFF">&nbsp;</td>
                    <td bgcolor="#FFFFFF">&nbsp;</td>
                    <td bgcolor="#FFFFFF">&nbsp;</td>
                    <td bgcolor="#FFFFFF">&nbsp;</td>
                    </tr>
                  <tr>
                    <td bgcolor="#FFFFFF">&nbsp;</td>
                    <td bgcolor="#FFFFFF">&nbsp;</td>
                    <td bgcolor="#FFFFFF">&nbsp;</td>
                    <td bgcolor="#FFFFFF">&nbsp;</td>
                    <td bgcolor="#FFFFFF">&nbsp;</td>
                    </tr>
                  <tr>
                    <td bgcolor="#FFFFFF">&nbsp;</td>
                    <td bgcolor="#FFFFFF">&nbsp;</td>
                    <td bgcolor="#FFFFFF">&nbsp;</td>
                    <td bgcolor="#FFFFFF">&nbsp;</td>
                    <td bgcolor="#FFFFFF">&nbsp;</td>
                    </tr>
                </table>
                <br />
              </fieldset></th>
            </tr>
          </table></td>
        </tr>
      </table></th>
    </tr>
  </table>
</form>
</body>
</html>
