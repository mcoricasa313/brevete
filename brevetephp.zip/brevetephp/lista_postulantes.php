<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/estilos.css" type="text/css" rel="stylesheet"/>

<title>Lista de postulantes</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <th align="center" scope="col"><table width="600" border="0" cellspacing="0" cellpadding="0" frame="border">
        <tr>
          <th bgcolor="#999999" scope="col">Listado de Postulantes</th>
        </tr>
        <tr>
          <td bgcolor="#E2E2E2" scope="col"><table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <th align="left" scope="col"><table width="100%" border="0" cellspacing="0" cellpadding="8">
                <tr>
                  <th scope="col"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <th width="30" align="center" scope="col"><img src="img/file_icon.png" alt="" width="20" height="20" /></th>
                      <th width="30" align="center" scope="col"><img src="img/cancel.png" alt="" width="20" height="20" /></th>
                      <th width="540" align="left" scope="col"><img src="img/flecha_atras.png" alt="" width="20" height="20" /></th>
                    </tr>
                  </table></th>
                </tr>
              </table></th>
            </tr>
            <tr>
              <th align="left" scope="col"><table width="100%" border="0" cellspacing="0" cellpadding="8">
                <tr>
                  <th align="left" scope="col"><fieldset>
                    <legend class="parrafo_negro">Busquedas</legend>
                    <table width="100%" border="0" cellspacing="3" cellpadding="0">
                      <tr>
                        <th width="15%" align="left" class="parrafo_negro" scope="col">Columnas</th>
                        <th width="16%" scope="col"><label for="select"></label>
                          <select name="select" id="select">
                          </select></th>
                        <th width="10%" class="parrafo_negro" scope="col">Valor</th>
                        <th width="59%" align="left" scope="col"><label for="textfield"></label>
                          <input name="textfield" type="text" id="textfield" size="40" /></th>
                      </tr>
                  </table>
                  </fieldset></th>
                </tr>
              </table></th>
            </tr>
            <tr>
              <th align="left" scope="col">&nbsp;</th>
            </tr>
            <tr>
              <th align="left" scope="col"><table width="100%" border="0" cellspacing="0" cellpadding="8">
                <tr>
                  <th scope="col"><table width="100%" border="1" cellspacing="0" cellpadding="0" bordercolor="#DFDFDF">
                    <tr>
                      <th width="25" bgcolor="#FFFFFF" scope="col">&nbsp;</th>
                      <th bgcolor="#FFFFFF" class="parrafo_negro" scope="col">Codigo</th>
                      <th bgcolor="#FFFFFF" class="parrafo_negro" scope="col">Conductor</th>
                      <th bgcolor="#FFFFFF" class="parrafo_negro" scope="col">Tramite</th>
                      <th bgcolor="#FFFFFF" class="parrafo_negro" scope="col">N° Licencias</th>
                      <th bgcolor="#FFFFFF" class="parrafo_negro" scope="col">Tipo Doc </th>
                      <th bgcolor="#FFFFFF" class="parrafo_negro" scope="col">N° Documento</th>
                    </tr>
                    <tr>
                      <td bgcolor="#FFFFFF">&nbsp;</td>
                      <td bgcolor="#FFFFFF">&nbsp;</td>
                      <td bgcolor="#FFFFFF">&nbsp;</td>
                      <td bgcolor="#FFFFFF">&nbsp;</td>
                      <td bgcolor="#FFFFFF">&nbsp;</td>
                      <td bgcolor="#FFFFFF">&nbsp;</td>
                      <td bgcolor="#FFFFFF">&nbsp;</td>
                    </tr>
                    <tr>
                      <td bgcolor="#FFFFFF">&nbsp;</td>
                      <td bgcolor="#FFFFFF">&nbsp;</td>
                      <td bgcolor="#FFFFFF">&nbsp;</td>
                      <td bgcolor="#FFFFFF">&nbsp;</td>
                      <td bgcolor="#FFFFFF">&nbsp;</td>
                      <td bgcolor="#FFFFFF">&nbsp;</td>
                      <td bgcolor="#FFFFFF">&nbsp;</td>
                    </tr>
                    <tr>
                      <td bgcolor="#FFFFFF">&nbsp;</td>
                      <td bgcolor="#FFFFFF">&nbsp;</td>
                      <td bgcolor="#FFFFFF">&nbsp;</td>
                      <td bgcolor="#FFFFFF">&nbsp;</td>
                      <td bgcolor="#FFFFFF">&nbsp;</td>
                      <td bgcolor="#FFFFFF">&nbsp;</td>
                      <td bgcolor="#FFFFFF">&nbsp;</td>
                    </tr>
                    <tr>
                      <td height="60" colspan="7" bgcolor="#999999">&nbsp;</td>
                    </tr>
                  </table></th>
                </tr>
              </table></th>
            </tr>
          </table></td>
        </tr>
      </table></th>
    </tr>
  </table>
</form>
</body>
</html>
