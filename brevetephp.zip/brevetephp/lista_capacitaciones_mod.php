<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/estilos.css" type="text/css" rel="stylesheet"/>

<title>Lista de Capacitaciones - Modificar</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table width="600" border="0" cellspacing="0" cellpadding="0" frame="border">
    <tr>
      <th bgcolor="#999999" scope="col">Registro de Capacitaciones</th>
    </tr>
    <tr>
      <td bgcolor="#E2E2E2"><table width="100%" border="0" cellspacing="0" cellpadding="5">
        <tr>
          <th scope="col"><table width="100%" border="0" cellspacing="0" cellpadding="3">
            <tr>
              <th colspan="2" align="left" bgcolor="#E2E2E2" scope="col"><img src="img/logo.jpg" alt="" width="220" height="58" /></th>
            </tr>
            <tr>
              <td colspan="2" align="left"><fieldset>
                <legend style="color: #000">Datos del conductor</legend>
                <table width="100%" border="0" cellspacing="0" cellpadding="3">
                  <tr>
                    <th width="18%" align="left" style="color: #000" scope="col">DNI</th>
                    <th width="19%" scope="col"><label for="textfield"></label>
                      <input type="text" name="textfield" id="textfield" /></th>
                    <th width="63%" align="left" scope="col"><input type="submit" name="button" id="button" value="Buscar" /></th>
                  </tr>
                  <tr>
                    <td align="left" style="color: #000">Nombres</td>
                    <td colspan="2"><label for="textfield2"></label>
                      <input name="textfield2" type="text" id="textfield2" size="100" readonly="readonly"/></td>
                  </tr>
                  <tr>
                    <td align="left" style="color: #000">Tramite</td>
                    <td colspan="2"><label for="textfield3"></label>
                      <input name="textfield3" type="text" id="textfield3" size="100" readonly="readonly"/></td>
                  </tr>
                </table>
                <br />
              </fieldset></td>
            </tr>
            <tr>
              <td width="64%" align="left"><fieldset>
                <legend style="color: #000">Cursos <br />
                  </legend>
                <table width="99%" border="0" cellspacing="5" cellpadding="0">
                  <tr>
                    <th width="24%" style="color: #000" scope="col">Cursos</th>
                    <th colspan="2" style="color: #000" scope="col">Nota</th>
                    <th colspan="2" style="color: #000" scope="col">Fecha</th>
                    <th width="31%" style="color: #000" scope="col">Locales</th>
                  </tr>
                  <tr>
                    <td><label for="select"></label>
                      <select name="select" id="select">
                      </select></td>
                    <td width="10%"><label for="textfield4"></label>
                      <input name="textfield4" type="text" id="textfield4" size="10" /></td>
                    <td width="10%"><input name="textfield5" type="text" id="textfield5" size="10" /></td>
                    <td width="10%"><select name="select7" id="select7">
                    </select></td>
                    <td width="15%"><select name="select8" id="select8">
                    </select></td>
                    <td><select name="select19" id="select19">
                    </select></td>
                  </tr>
                  <tr>
                    <td><select name="select2" id="select2">
                    </select></td>
                    <td><input name="textfield6" type="text" id="textfield6" size="10" /></td>
                    <td><input name="textfield7" type="text" id="textfield7" size="10" /></td>
                    <td><select name="select9" id="select9">
                    </select></td>
                    <td><select name="select10" id="select10">
                    </select></td>
                    <td><select name="select20" id="select20">
                    </select></td>
                  </tr>
                  <tr>
                    <td><select name="select3" id="select3">
                    </select></td>
                    <td><input name="textfield8" type="text" id="textfield8" size="10" /></td>
                    <td><input name="textfield9" type="text" id="textfield9" size="10" /></td>
                    <td><select name="select11" id="select11">
                    </select></td>
                    <td><select name="select12" id="select12">
                    </select></td>
                    <td><select name="select21" id="select21">
                    </select></td>
                  </tr>
                  <tr>
                    <td><select name="select4" id="select4">
                    </select></td>
                    <td><input name="textfield10" type="text" id="textfield10" size="10" /></td>
                    <td><input name="textfield11" type="text" id="textfield11" size="10" /></td>
                    <td><select name="select13" id="select13">
                    </select></td>
                    <td><select name="select14" id="select14">
                    </select></td>
                    <td><select name="select22" id="select22">
                    </select></td>
                  </tr>
                  <tr>
                    <td><select name="select5" id="select5">
                    </select></td>
                    <td><input name="textfield12" type="text" id="textfield12" size="10" /></td>
                    <td><input name="textfield13" type="text" id="textfield13" size="10" /></td>
                    <td><select name="select15" id="select15">
                    </select></td>
                    <td><select name="select16" id="select16">
                    </select></td>
                    <td><select name="select24" id="select24">
                    </select></td>
                  </tr>
                  <tr>
                    <td><select name="select6" id="select6">
                    </select></td>
                    <td><input name="textfield14" type="text" id="textfield14" size="10" /></td>
                    <td><input name="textfield15" type="text" id="textfield15" size="10" /></td>
                    <td><select name="select17" id="select17">
                    </select></td>
                    <td><select name="select18" id="select18">
                    </select></td>
                    <td><select name="select23" id="select23">
                    </select></td>
                  </tr>
                  <tr>
                    <td colspan="3" align="center"><span style="color: #000">Numero de certificado</span></td>
                    <td colspan="2"><label for="textfield16"></label>
                      <input type="text" name="textfield16" id="textfield16" /></td>
                    <td><input type="submit" name="button2" id="button2" value="Enviar" /></td>
                  </tr>
                </table>
              </fieldset></td>
              <td width="36%" align="left" valign="top"><fieldset>
                <legend style="color: #000">Resultados</legend>
                <br />
                <table width="100%" border="0" cellspacing="5" cellpadding="0">
                  <tr>
                    <th colspan="4" scope="col"><span style="color: #000">Practicas de manejo</span></th>
                  </tr>
                  <tr>
                    <td width="22%" style="color: #000">Horas </td>
                    <td width="23%"><span style="color: #000">Nota</span></td>
                    <td width="24%"><span style="color: #000">Fecha</span></td>
                    <td width="31%"><span style="color: #000">Locales</span></td>
                  </tr>
                  <tr>
                    <td><input name="textfield17" type="text" id="textfield17" size="10" /></td>
                    <td><input name="textfield19" type="text" id="textfield19" size="10" /></td>
                    <td><select name="select25" id="select25">
                    </select></td>
                    <td><select name="select27" id="select27">
                    </select></td>
                  </tr>
                  <tr>
                    <td><input name="textfield18" type="text" id="textfield18" size="10" /></td>
                    <td><input name="textfield20" type="text" id="textfield20" size="10" /></td>
                    <td><select name="select26" id="select26">
                    </select></td>
                    <td><select name="select28" id="select28">
                    </select></td>
                  </tr>
                </table>
              </fieldset></td>
            </tr>
            <tr>
              <td colspan="2" align="left"><fieldset style="color: #000">
                <legend>Datos de impresion</legend>
                <br />
                <table width="100%" border="0" cellspacing="3" cellpadding="0">
                  <tr>
                    <th width="15%" align="left" style="color: #000" scope="col">N° Cerificado</th>
                    <th width="21%" align="left" scope="col"><label for="textfield22"></label>
                      <input type="text" name="textfield22" id="textfield22" /></th>
                    <th width="14%" align="left" scope="col">&nbsp;</th>
                    <th width="7%" align="left" scope="col">&nbsp;</th>
                    <th width="10%" align="left" scope="col">&nbsp;</th>
                    <th width="10%" scope="col">&nbsp;</th>
                    <th width="10%" scope="col">&nbsp;</th>
                    <th width="13%" scope="col">&nbsp;</th>
                  </tr>
                  <tr>
                    <td align="left" style="color: #000">Fecha inicio</td>
                    <td align="left"><label for="select29"></label>
                      <select name="select29" id="select29">
                      </select></td>
                    <td align="left" style="color: #000">Fecha Fin</td>
                    <td align="left"><select name="select30" id="select30">
                    </select></td>
                    <td align="left">&nbsp;</td>
                    <td><input name="button3" type="submit" class="btn_numeros" id="button3" value="Nuevo" /></td>
                    <td><input name="button4" type="submit" class="btn_numeros" id="button4" value="Grabar" /></td>
                    <td><input name="button5" type="submit" class="btn_numeros" id="button5" value="Cancelar" /></td>
                  </tr>
                  <tr>
                    <td align="left" style="color: #000">Promedio</td>
                    <td align="left"><label for="textfield21"></label>
                      <input name="textfield21" type="text" id="textfield21" size="5" /></td>
                    <td align="left">&nbsp;</td>
                    <td align="left">&nbsp;</td>
                    <td align="left">&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                  </tr>
                </table>
              </fieldset></td>
            </tr>
          </table></th>
        </tr>
      </table></td>
    </tr>
  </table>
</form>
</body>
</html>
